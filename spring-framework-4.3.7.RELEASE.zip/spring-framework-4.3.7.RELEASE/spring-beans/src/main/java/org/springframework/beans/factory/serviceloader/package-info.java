/**
 * Support package for the Java 6 ServiceLoader facility.
 */
package org.springframework.beans.factory.serviceloader;
