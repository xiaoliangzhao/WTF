/**
 * Support infrastructure for bean definition parsing.
 */
package org.springframework.beans.factory.parsing;
